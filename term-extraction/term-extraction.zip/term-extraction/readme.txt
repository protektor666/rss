Five Filters : Term Extraction

Please see http://fivefilters.org/term-extraction/ for information